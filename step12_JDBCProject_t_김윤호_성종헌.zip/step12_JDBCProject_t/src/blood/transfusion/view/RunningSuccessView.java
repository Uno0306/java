package blood.transfusion.view;

public class RunningSuccessView {
	public static void showSuccess(String msg) {
		System.out.println(msg);
	}
}
